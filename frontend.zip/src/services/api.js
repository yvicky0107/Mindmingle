import axios from "axios";

const API = axios.create({
  baseURL: "http://localhost:4000/api", // ✅ backend running on 4000
});

// Attach token automatically for every request
API.interceptors.request.use((req) => {
  const token = localStorage.getItem("token");
  if (token) {
    req.headers.Authorization = `Bearer ${token}`;
  }
  return req;
});

// ====================
// AUTH
// ====================
export const signupUser = (data) => API.post("/auth/signup", data);
export const loginUser = (data) => API.post("/auth/login", data);

// ====================
// MOODS
// ====================
export const saveMood = (data) => {
  const token = localStorage.getItem("token");
  return API.post("/moods", data, {
    headers: { Authorization: `Bearer ${token}` },
  });
};

export const getMoods = () => {
  const token = localStorage.getItem("token");
  return API.get("/moods", {
    headers: { Authorization: `Bearer ${token}` },
  });
};
