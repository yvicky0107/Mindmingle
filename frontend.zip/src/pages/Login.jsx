import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../services/api";
import AuthLayout from "../components/AuthLayout";

function Login() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [emailError, setEmailError] = useState("");

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setError("");

    if (e.target.name === "email") {
      if (!emailRegex.test(e.target.value)) {
        setEmailError(
          "⚠️ Please enter a valid email (e.g., user@example.com)"
        );
      } else {
        setEmailError("");
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!emailRegex.test(form.email)) {
      setEmailError("⚠️ Please enter a valid email (e.g., user@example.com)");
      return;
    }

    try {
      const res = await loginUser(form);
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("name", res.data.user.name);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.msg || "❌ Invalid credentials");
    }
  };

  return (
    <AuthLayout title="Log In">
      {error && <p className="text-danger text-center">{error}</p>}

      <form onSubmit={handleSubmit}>
        {/* Email */}
        <div className="mb-3">
          <input
            type="email"
            name="email"
            placeholder="Enter your email"
            className={`form-control ${emailError ? "is-invalid" : ""}`}
            value={form.email}
            onChange={handleChange}
            required
          />
          {emailError && (
            <div className="invalid-feedback">{emailError}</div>
          )}
        </div>

        {/* Password */}
        <div className="mb-3">
          <input
            type="password"
            name="password"
            placeholder="Enter your password"
            className="form-control"
            value={form.password}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="btn btn-primary w-100">
          Login
        </button>
      </form>

      <p className="text-center mt-3">
        New user?{" "}
        <span
          className="text-primary"
          style={{ cursor: "pointer" }}
          onClick={() => navigate("/signup")}
        >
          Sign Up
        </span>
      </p>
    </AuthLayout>
  );
}

export default Login;
