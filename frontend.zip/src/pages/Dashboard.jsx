import React, { useEffect, useState } from "react";
import { saveMood, getMoods } from "../services/api";
import { Card, Badge } from "react-bootstrap";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  ScatterChart,
  Scatter,
  ResponsiveContainer,
} from "recharts";
import { format, parseISO } from "date-fns";
import Navbar from "../components/Navbar";

const moodMap = {
  happy: "😊 Happy",
  sad: "😢 Sad",
  angry: "😡 Angry",
  calm: "😌 Calm",
  stressed: "😰 Stressed",
};

const moodColors = {
  happy: "#00C49F",
  calm: "#0088FE",
  angry: "#FF4444",
  sad: "#8884D8",
  stressed: "#FFBB28",
};

function Dashboard() {
  const [mood, setMood] = useState("");
  const [note, setNote] = useState("");
  const [history, setHistory] = useState([]);
  const [username, setUsername] = useState("");
  const [todayMood, setTodayMood] = useState(null); // ✅ new
  const [currentMood, setCurrentMood] = useState(null); // ✅ new

  useEffect(() => {
    fetchMoods();
    const storedName = localStorage.getItem("name");
    if (storedName) setUsername(storedName);
  }, []);

  const fetchMoods = async () => {
    try {
      const res = await getMoods();
      const normalized = res.data.map((m) => ({
        ...m,
        mood: m.mood.toLowerCase(),
        createdAt: m.createdAt,
        date: format(new Date(m.createdAt), "dd MMM"),
        time: format(new Date(m.createdAt), "hh:mm a"),
      }));
      setHistory(normalized);

      // ✅ Current mood (latest entry)
      if (normalized.length > 0) {
        setCurrentMood(normalized[0]);
      }

      // ✅ Today’s overall mood (most frequent today)
      const today = format(new Date(), "dd MMM");
      const todaysLogs = normalized.filter((m) => m.date === today);
      if (todaysLogs.length > 0) {
        const counts = todaysLogs.reduce((acc, entry) => {
          acc[entry.mood] = (acc[entry.mood] || 0) + 1;
          return acc;
        }, {});
        const topMood = Object.keys(counts).reduce((a, b) =>
          counts[a] > counts[b] ? a : b
        );
        setTodayMood({ mood: topMood, count: counts[topMood] });
      }
    } catch (err) {
      console.error("❌ Error fetching moods", err);
    }
  };

  const handleSaveMood = async () => {
    try {
      if (!mood) return alert("Please select a mood!");
      const cleanMood = mood.toLowerCase();
      await saveMood({ mood: cleanMood, note });

      alert("✅ Mood saved successfully!");
      setMood("");
      setNote("");
      fetchMoods();
    } catch (err) {
      alert("❌ Error saving mood");
    }
  };

  const moodCounts = Object.values(
    history.reduce((acc, entry) => {
      acc[entry.mood] = acc[entry.mood] || { mood: entry.mood, count: 0 };
      acc[entry.mood].count += 1;
      return acc;
    }, {})
  );

  const trendData = Object.values(
    history.reduce((acc, entry) => {
      if (!acc[entry.date]) acc[entry.date] = { date: entry.date };
      acc[entry.date][entry.mood] = (acc[entry.date][entry.mood] || 0) + 1;
      return acc;
    }, {})
  );

  const scatterData = history.map((entry) => ({
    date: entry.date,
    time: parseISO(entry.createdAt).getHours() +
      parseISO(entry.createdAt).getMinutes() / 60,
    mood: entry.mood,
    note: entry.note,
  }));

  const totalMoodCounts = moodCounts.map((m) => ({
    mood: moodMap[m.mood],
    count: m.count,
    color: moodColors[m.mood],
  }));

  return (
    <div style={{ minHeight: "100vh", background: "linear-gradient(135deg,#6a11cb,#2575fc)" }}>
      <Navbar />

      <div className="container py-5 text-white">
        <div className="text-center mb-5">
          <h1 className="fw-bold display-5">
            Welcome back {username ? username : ""} 👋
          </h1>
          <p className="lead">Your wellness overview</p>
        </div>

        {/* ✅ New section for Today’s Overall + Current Mood */}
        <div className="row mb-5 text-center">
          <div className="col-md-6">
            <Card className="p-4 shadow-sm">
              <h5>🌞 Today’s Overall Mood</h5>
              <p className="display-6 text-dark">
                {todayMood
                  ? `${moodMap[todayMood.mood]} (${todayMood.count} times)`
                  : "No logs today"}
              </p>
            </Card>
          </div>
          <div className="col-md-6">
            <Card className="p-4 shadow-sm">
              <h5>🕒 Current Mood</h5>
              <p className="display-6 text-dark">
                {currentMood ? moodMap[currentMood.mood] : "No current mood"}
              </p>
            </Card>
          </div>
        </div>

        {/* Mood Entry (unchanged) */}
        <Card className="shadow-lg mb-5 p-4 rounded-4 border-0">
          <h4 className="mb-3">✨ Your Mood Today</h4>
          <select
            className="form-select mb-3"
            value={mood}
            onChange={(e) => setMood(e.target.value)}
          >
            <option value="">Select mood</option>
            {Object.keys(moodMap).map((key) => (
              <option key={key} value={key}>
                {moodMap[key]}
              </option>
            ))}
          </select>
          <textarea
            className="form-control mb-3"
            placeholder="Add a note..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <button className="btn btn-primary w-100 btn-lg" onClick={handleSaveMood}>
            Save Mood
          </button>
        </Card>

        {/* 📊 Charts */}
        <h4 className="mb-4">📊 Mood Insights</h4>
        <div className="row g-4">
          {/* Pie Chart */}
          <div className="col-md-4">
            <Card className="p-4 shadow-sm">
              <h5>Mood Distribution</h5>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={moodCounts}
                    dataKey="count"
                    nameKey="mood"
                    outerRadius={80}
                    label={({ name, value }) => `${moodMap[name]}: ${value}`}
                  >
                    {moodCounts.map((entry, index) => (
                      <Cell key={index} fill={moodColors[entry.mood]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(val, name) => [val, moodMap[name] || name]} />
                  <Legend formatter={(value) => moodMap[value] || value} />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Stacked Bar Chart for Mood Trend */}
          <div className="col-md-8">
            <Card className="p-4 shadow-sm">
              <h5>Mood Trend (Daily Counts)</h5>
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={trendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis allowDecimals={false} />
                  <Tooltip />
                  <Legend />
                  {Object.keys(moodColors).map((m) => (
                    <Bar key={m} dataKey={m} stackId="a" fill={moodColors[m]} name={moodMap[m]} />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </div>

          {/* Scatter Chart for Daily Timeline */}
          <div className="col-md-12">
            <Card className="p-4 shadow-sm">
              <h5>Daily Mood Timeline</h5>
              <ResponsiveContainer width="100%" height={250}>
                <ScatterChart>
                  <CartesianGrid />
                  <XAxis
                    dataKey="time"
                    type="number"
                    domain={[0, 24]}
                    tickFormatter={(h) =>
                      `${String(Math.floor(h)).padStart(2, "0")}:${String(Math.round((h % 1) * 60)).padStart(2, "0")}`
                    }
                    label={{ value: "Time of Day", position: "insideBottom", dy: 10 }}
                  />
                  <YAxis
                    type="category"
                    dataKey="mood"
                    tickFormatter={(m) => moodMap[m]}
                    allowDuplicatedCategory={false}
                  />
                  <Tooltip
                    cursor={{ strokeDasharray: "3 3" }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;

                        // Format time → convert float hours back to HH:mm
                        const hours = Math.floor(data.time);
                        const minutes = Math.round((data.time % 1) * 60);
                        const formattedTime = `${String(hours).padStart(2, "0")}:${String(
                          minutes
                        ).padStart(2, "0")} HRS`;

                        return (
                          <div
                            style={{
                              background: "white",
                              padding: "8px",
                              borderRadius: "8px",
                              color: "#333",
                            }}
                          >
                            <strong>{moodMap[data.mood]}</strong>
                            <div>⏰ {formattedTime}</div>
                            {data.note && <div>📝 {data.note}</div>}
                          </div>
                        );
                      }
                      return null;
                    }}
                  />

                  <Scatter
                    data={scatterData}
                    shape={(props) => (
                      <circle
                        cx={props.cx}
                        cy={props.cy}
                        r={6}
                        fill={moodColors[props.payload.mood]}
                      />
                    )}
                  />
                </ScatterChart>
              </ResponsiveContainer>
            </Card>
          </div>
        </div>

        {/* Mood Totals Summary */}
        <Card className="p-3 mt-4 shadow-sm text-center">
          <h5>Total Mood Counts</h5>
          <div>
            {totalMoodCounts.map((m, i) => (
              <Badge key={i} bg="light" text="dark" className="m-2 p-2">
                <span style={{ color: m.color, fontSize: "1.2em" }}>●</span> {m.mood}: {m.count}
              </Badge>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export default Dashboard;
