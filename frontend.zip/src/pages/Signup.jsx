import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { signupUser } from "../services/api";
import AuthLayout from "../components/AuthLayout";

function Signup() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    gender: "",
    email: "",
    phone: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [success, setSuccess] = useState("");
  const [isFormValid, setIsFormValid] = useState(false);

  // Regex patterns
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const phoneRegex = /^[6-9]\d{9}$/;
  const passwordRegex =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

  // Validation function
  const validateField = (name, value) => {
    switch (name) {
      case "name":
        return value ? "" : "Name is required";
      case "gender":
        return value ? "" : "Gender is required";
      case "email":
        if (!value) return "Email is required";
        return emailRegex.test(value)
          ? ""
          : "Please enter a valid email (e.g., name@example.com)";
      case "phone":
        if (!value) return "Phone is required";
        return phoneRegex.test(value)
          ? ""
          : "Phone must be 10 digits and start with 6-9";
      case "password":
        if (!value) return "Password is required";
        return passwordRegex.test(value)
          ? ""
          : "Password must be 8+ chars, include uppercase, lowercase, number, special symbol";
      default:
        return "";
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });

    const errorMsg = validateField(name, value);
    setErrors({ ...errors, [name]: errorMsg });
  };

  useEffect(() => {
    const allValid =
      form.name &&
      form.gender &&
      emailRegex.test(form.email) &&
      phoneRegex.test(form.phone) &&
      passwordRegex.test(form.password);

    setIsFormValid(allValid);
  }, [form]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await signupUser(form);

      localStorage.setItem("token", res.data.token);
      localStorage.setItem("name", res.data.user.name);
      setSuccess("✅ Signup successful! Redirecting to Dashboard..."); 
      setTimeout(() => navigate("/dashboard"), 2000);
      
    } catch (err) {
      setSuccess("");
      setErrors({ api: err.response?.data?.msg || "❌ Signup failed" });
    }
  };

  return (
    <AuthLayout title="Sign Up">
      {errors.api && <p className="text-danger text-center">{errors.api}</p>}
      {success && <p className="text-success text-center">{success}</p>}

      <form onSubmit={handleSubmit}>
        {/* Name */}
        <div className="mb-3">
          <input
            type="text"
            name="name"
            placeholder="Enter your name"
            className={`form-control ${errors.name ? "is-invalid" : ""}`}
            value={form.name}
            onChange={handleChange}
          />
          {errors.name && <div className="invalid-feedback">{errors.name}</div>}
        </div>

        {/* Gender */}
        <div className="mb-3">
          <label className="form-label">Gender</label>
          <div
            className={`border rounded p-2 ${
              errors.gender ? "is-invalid border-danger" : ""
            }`}
          >
            {["Male", "Female", "Other"].map((g) => (
              <label key={g} className="me-3">
                <input
                  type="radio"
                  name="gender"
                  value={g}
                  checked={form.gender === g}
                  onChange={handleChange}
                />{" "}
                {g}
              </label>
            ))}
          </div>
          {errors.gender && (
            <div className="invalid-feedback d-block">{errors.gender}</div>
          )}
        </div>

        {/* Email */}
        <div className="mb-3">
          <input
            type="email"
            name="email"
            placeholder="Enter your email"
            className={`form-control ${errors.email ? "is-invalid" : ""}`}
            value={form.email}
            onChange={handleChange}
          />
          {errors.email && (
            <div className="invalid-feedback">{errors.email}</div>
          )}
        </div>

        {/* Phone */}
        <div className="mb-3">
          <input
            type="text"
            name="phone"
            placeholder="Enter your phone"
            className={`form-control ${errors.phone ? "is-invalid" : ""}`}
            value={form.phone}
            onChange={handleChange}
          />
          {errors.phone && (
            <div className="invalid-feedback">{errors.phone}</div>
          )}
        </div>

        {/* Password */}
        <div className="mb-3">
          <input
            type="password"
            name="password"
            placeholder="Enter your password"
            className={`form-control ${errors.password ? "is-invalid" : ""}`}
            value={form.password}
            onChange={handleChange}
          />
          {errors.password && (
            <div className="invalid-feedback">{errors.password}</div>
          )}
        </div>

        <button
          type="submit"
          className="btn btn-primary w-100"
          disabled={!isFormValid}
        >
          Sign Up
        </button>
      </form>

      <p className="text-center mt-3">
        Already have an account?{" "}
        <span
          className="text-primary"
          style={{ cursor: "pointer" }}
          onClick={() => navigate("/login")}
        >
          Log In
        </span>
      </p>
    </AuthLayout>
  );
}

export default Signup;
