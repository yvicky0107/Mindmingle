import React, { useRef } from "react";
import { useNavigate } from "react-router-dom";
import "./Landing.css";

function Landing() {
  const navigate = useNavigate();

  // Ref for the Features section
  const featuresRef = useRef(null);

  // Scroll function
  const scrollToFeatures = () => {
    featuresRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // ✅ Handle "Get Started" or "Join Now"
  const handleGetStarted = () => {
    if (localStorage.getItem("token")) {
      navigate("/dashboard");
    } else {
      navigate("/signup");
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section
        className="text-center text-white d-flex align-items-center justify-content-center flex-column"
        style={{
          minHeight: "88vh",
          background: "linear-gradient(135deg, #6a11cb 0%, #2575fc 100%)",
          position: "relative",
        }}
      >
        <div>
          <h1 className="display-3 fw-bold">Find Inner Peace with Mindmingle</h1>
          <p className="lead mt-3">
            Your personal companion for mental wellness. Meditation, mood
            tracking, and peer support — all in one place.
          </p>
          <div className="mt-4">
            <button
              className="btn btn-light btn-lg me-3"
              onClick={handleGetStarted}
            >
              Get Started Free
            </button>
            <button
              className="btn btn-outline-light btn-lg"
              onClick={scrollToFeatures}
            >
              Learn More
            </button>
          </div>
        </div>

        {/* Scroll Down Indicator */}
        <div
          style={{
            position: "absolute",
            bottom: "20px",
            fontSize: "24px",
            animation: "bounce 1.5s infinite",
          }}
        >
          ↓
        </div>
      </section>

      {/* Features Section */}
      <section ref={featuresRef} className="py-5 bg-light text-dark">
        <div className="container text-center">
          <h2 className="fw-bold mb-5">Why Choose Mindmingle?</h2>
          <div className="row g-4">
            <div className="col-md-4">
              <div className="card feature-card h-100">
                <img
                  src="/images/mindfulness.png"
                  className="card-img-top"
                  alt="Mindfulness"
                />
                <div className="card-body">
                  <h5 className="card-title">🧘 Mindfulness Exercises</h5>
                  <p className="card-text">
                    Relax and recharge with guided meditation practices.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100">
                <img
                  src="/images/mood-tracking.png"
                  className="card-img-top"
                  alt="Mood Tracking"
                />
                <div className="card-body">
                  <h5 className="card-title">📊 Mood Tracking</h5>
                  <p className="card-text">
                    Track your emotions daily and discover patterns.
                  </p>
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card feature-card h-100">
                <img
                  src="/images/peer-support.png"
                  className="card-img-top"
                  alt="Peer Support"
                />
                <div className="card-body">
                  <h5 className="card-title">🤝 Peer Support</h5>
                  <p className="card-text">
                    Connect anonymously with others who understand you.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section
        className="text-center text-white py-5"
        style={{ background: "#2575fc" }}
      >
        <h2 className="fw-bold">Start your wellness journey today</h2>
        <button
          className="btn btn-light btn-lg mt-3"
          onClick={handleGetStarted}
        >
          Join Now
        </button>
      </section>

      {/* Footer */}
      <footer className="bg-dark text-white text-center py-3">
        <p>© {new Date().getFullYear()} Mindmingle. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default Landing;
