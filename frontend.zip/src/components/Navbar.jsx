import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { FaUserCircle } from "react-icons/fa";

function Navbar() {
  const navigate = useNavigate();
  const token = localStorage.getItem("token");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("name"); // clear stored username too
    navigate("/login");
  };

  // ✅ Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <nav className="navbar px-4">
      {/* Logo */}
      <span
        className="navbar-brand text-light mb-0 h1"
        style={{ cursor: "pointer" }}
        onClick={() => navigate("/")}
      >
        Mindmingle
      </span>

      {/* Links (conditional) */}
      <div className="d-flex align-items-center">
        {token ? (
          <>
            {/* Logged in links */}
            <button
              className="btn btn-link text-white me-3"
              onClick={() => navigate("/about")}
            >
              About Us
            </button>
            <button
              className="btn btn-link text-white me-3"
              onClick={() => navigate("/dashboard")}
            >
              Dashboard
            </button>

            {/* Profile dropdown */}
            <div className="position-relative" ref={dropdownRef}>
              <button
                className="btn btn-dark d-flex align-items-center"
                onClick={() => setDropdownOpen(!dropdownOpen)}
              >
                <FaUserCircle size={24} className="me-1" />
              </button>
              {dropdownOpen && (
                <ul
                  className="dropdown-menu dropdown-menu-end show"
                  style={{ position: "absolute", right: 0 }}
                >
                  <li>
                    <button
                      className="dropdown-item"
                      onClick={() => {
                        setDropdownOpen(false);
                        navigate("/profile");
                      }}
                    >
                      My Profile
                    </button>
                  </li>
                  <li>
                    <button
                      className="dropdown-item text-danger"
                      onClick={handleLogout}
                    >
                      Logout
                    </button>
                  </li>
                </ul>
              )}
            </div>
          </>
        ) : (
          <>
            {/* Logged out links */}
            <button
              className="btn btn-outline-light me-2"
              onClick={() => navigate("/login")}
            >
              Login
            </button>
            <button
              className="btn btn-primary"
              onClick={() => navigate("/signup")}
            >
              Sign Up
            </button>
          </>
        )}
      </div>
    </nav>
  );
}

export default Navbar;
