import React from "react";
import Navbar from "./Navbar";
import "./AuthLayout.css";

function AuthLayout({ children, title }) {
  return (
    <div className="auth-layout">
      {/* Navbar */}
      <div className="auth-navbar">
        <Navbar />
      </div>

      <div className="container-fluid min-vh-100 d-flex align-items-center">
        <div className="row w-100">
          {/* Left Side - hidden on mobile */}
          <div className="col-lg-6 d-none d-lg-flex flex-column justify-content-center text-white p-5 auth-left">
            <h1 className="fw-bold display-4">Find Inner Peace with Mindmingle</h1>
            <p className="lead mt-3">
              Your personal companion for mental wellness. Meditation, mood
              tracking, and mindfulness — all in one place.
            </p>
          </div>

          {/* Right Side - form always visible */}
          <div className="col-12 col-md-8 col-lg-5 mx-auto d-flex align-items-center">
            <div className="card shadow-lg p-4 rounded-4 auth-card w-100">
              <h2 className="text-center mb-4">{title}</h2>
              {children}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AuthLayout;
